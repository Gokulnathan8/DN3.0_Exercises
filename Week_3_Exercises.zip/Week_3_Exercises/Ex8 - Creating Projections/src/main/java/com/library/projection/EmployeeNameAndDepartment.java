package com.library.projection;

public interface EmployeeNameAndDepartment {
    String getName();
    String getDepartment();
}