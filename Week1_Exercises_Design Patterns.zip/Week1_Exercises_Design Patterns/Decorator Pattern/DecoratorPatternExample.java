/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Week_1_Exercises;

/**
 *
 * @author HP
 */
public class DecoratorPatternExample {
    public static void main(String[] args) {
        Notifier notifier = new EmailNotifier();
        
        // Send email
        notifier.send("Hello via Email!");

        // Send email and SMS
        Notifier smsNotifier = new SMSNotifierDecorator(notifier);
        smsNotifier.send("Hello via Email and SMS!");

        // Send email, SMS, and Slack
        Notifier slackNotifier = new SlackNotifierDecorator(smsNotifier);
        slackNotifier.send("Hello via Email, SMS, and Slack!");
    }
}
