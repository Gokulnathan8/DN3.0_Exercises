package com.library.BookStoreAPI.model;

public class JwtRequest {
    private String username;
    private String password;

    public String getUsername() {
        return "";
    }

    public Object getPassword() {
        return null;
    }

    // Getters and Setters
}

