CREATE OR REPLACE PROCEDURE ProcessMonthlyInterest IS
BEGIN
FOR account IN (SELECT AccountID, Balance FROM Accounts WHERE AccountType = 'Savings') LOOP
UPDATE Accounts
SET Balance = Balance * 1.01
WHERE AccountID = account.AccountID;
END LOOP;
COMMIT;
END ProcessMonthlyInterest;
/