DECLARE
  CURSOR c_transactions IS
    SELECT AccountID, TransactionDate, Amount, TransactionType
    FROM Transactions
    WHERE TransactionDate BETWEEN TRUNC(SYSDATE, 'MM') AND LAST_DAY(SYSDATE);
BEGIN
  FOR transaction IN c_transactions LOOP
    DBMS_OUTPUT.PUT_LINE('Account '||transaction.AccountID||': '||
    transaction.TransactionType ||' of '||
    transaction.Amount ||' on '|| transaction.TransactionDate);
  END LOOP;
END;
/
