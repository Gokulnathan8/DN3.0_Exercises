BEGIN
  FOR customer IN (SELECT CustomerID, DOB FROM Customers) LOOP
    IF TRUNC(MONTHS_BETWEEN(SYSDATE, customer.DOB) / 12) > 60 THEN
      UPDATE Loans
      SET InterestRate = InterestRate - 1
      WHERE CustomerID = customer.CustomerID;
    END IF;
  END LOOP;
END;
/
